import 'package:alarmfy/src/app.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());