import 'package:alarmfy/src/models/authorization_model.dart';

import 'package:rxdart/rxdart.dart';

class DeleteplaylistBloc {
  final PublishSubject _deletelistTokenFetcher =
      PublishSubject<AuthorizationModel>();
  final PublishSubject _deletelistCodeFetcher = PublishSubject<String>();

  Observable<String> get deletelistCode => _deletelistCodeFetcher.stream;
  Observable<AuthorizationModel> get deletelistToken =>
      _deletelistTokenFetcher.stream;
}

final DeleteplaylistBloc deleteplaylistBloc = DeleteplaylistBloc();
