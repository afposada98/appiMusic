import 'package:alarmfy/src/models/authorization_model.dart';

import 'package:rxdart/rxdart.dart';

class AddplaylistBloc {
  final PublishSubject _addlistTokenFetcher =
      PublishSubject<AuthorizationModel>();
  final PublishSubject _addlistCodeFetcher = PublishSubject<String>();

  Observable<String> get addlistCode => _addlistCodeFetcher.stream;
  Observable<AuthorizationModel> get addlistToken =>
      _addlistTokenFetcher.stream;
}

final AddplaylistBloc addplaylistBloc = AddplaylistBloc();
